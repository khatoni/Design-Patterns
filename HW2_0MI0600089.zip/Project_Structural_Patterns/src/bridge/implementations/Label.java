package bridge.implementations;

public interface Label {

    public String getText();

}
