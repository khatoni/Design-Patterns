package transformations;

public interface TransformationBase {

    String transform(String text);
}
